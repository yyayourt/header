import React from 'react';
import Header from './components/Header';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <main className="pt-24">
        {/* Main content will go here */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative h-[500px] rounded-2xl overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&q=80&w=1974"
              alt="Salon de coiffure moderne"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex items-center">
              <div className="p-8 sm:p-12 max-w-xl text-white">
                <h1 className="text-4xl sm:text-5xl font-bold mb-4">
                  Révélez votre beauté naturelle
                </h1>
                <p className="text-lg mb-8">
                  Une expérience de coiffure unique dans un cadre luxueux et
                  accueillant
                </p>
                <a
                  href="#reservations"
                  className="inline-block px-6 py-3 rounded-full bg-rose-500 text-white font-medium hover:bg-rose-600 transition-colors"
                >
                  Réserver maintenant
                </a>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
