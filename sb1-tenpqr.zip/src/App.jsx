import React from 'react'
import Header from './components/Header/Header'

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="pt-16">
        {/* Le contenu principal sera ajouté ici */}
      </main>
    </div>
  )
}

export default App