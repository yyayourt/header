import React from 'react';
import Header from './components/Header/Header';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <main className="pt-32 px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-8">
            Bienvenue chez StyleHub
          </h1>
          {/* Rest of your content */}
        </div>
      </main>
    </div>
  );
}

export default App;