import React from 'react';
import Header from './components/Header';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      <main className="pt-24">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-serif">Bienvenue chez L'Atelier</h1>
          {/* Add your main content here */}
        </div>
      </main>
    </div>
  );
}

export default App;