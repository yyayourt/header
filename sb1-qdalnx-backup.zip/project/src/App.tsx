import React from 'react';
import Header from './components/Header/Header';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-serif text-center">Bienvenue chez Coiffure Elite</h1>
        {/* Add your main content here */}
      </main>
    </div>
  );
}

export default App;