import { motion, useScroll, useTransform } from 'framer-motion';
import { Logo } from './Logo';
import { Navigation } from './Navigation';
import { BookingButton } from './BookingButton';

export const Header = () => {
  const { scrollY } = useScroll();
  const headerBackground = useTransform(
    scrollY,
    [0, 100],
    ['rgba(26, 26, 26, 0)', 'rgba(26, 26, 26, 0.95)']
  );

  return (
    <motion.header
      style={{ backgroundColor: headerBackground }}
      className="fixed top-0 left-0 right-0 z-50 backdrop-blur-sm"
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Logo />
          <div className="flex items-center gap-4">
            <BookingButton />
            <Navigation />
          </div>
        </div>
      </div>
    </motion.header>
  );
};