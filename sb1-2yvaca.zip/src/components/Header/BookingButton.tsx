import { motion } from 'framer-motion';
import { Calendar } from 'lucide-react';

export const BookingButton = () => {
  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-luxury-dark bg-luxury-gold rounded-full shadow-lg hover:bg-luxury-silver transition-colors duration-300"
    >
      <Calendar className="w-4 h-4" />
      <span>Réserver</span>
    </motion.button>
  );
};