import { motion } from 'framer-motion';
import { Scissors } from 'lucide-react';

export const Logo = () => {
  return (
    <motion.div
      className="flex items-center gap-2 cursor-pointer"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <motion.div
        className="text-luxury-gold"
        animate={{ rotate: [0, 15, -15, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      >
        <Scissors className="w-8 h-8" />
      </motion.div>
      <span className="font-serif text-2xl font-bold bg-gradient-to-r from-luxury-gold to-luxury-silver bg-clip-text text-transparent">
        LUXE
      </span>
    </motion.div>
  );
};