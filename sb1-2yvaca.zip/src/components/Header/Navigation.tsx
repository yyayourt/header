import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Instagram, Facebook, Twitter } from 'lucide-react';
import { useState } from 'react';

const menuItems = [
  { title: 'Accueil', href: '#' },
  { title: 'Services Exclusifs', href: '#services' },
  { title: 'Réservations VIP', href: '#reservations' },
  { title: 'Stylistes Célébrités', href: '#stylists' },
  { title: 'Galerie 360°', href: '#gallery' },
  { title: 'Avis', href: '#reviews' },
  { title: 'Contact', href: '#contact' },
];

const socialLinks = [
  { icon: Instagram, href: '#' },
  { icon: Facebook, href: '#' },
  { icon: Twitter, href: '#' },
];

export const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <motion.button
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="relative z-50 p-2"
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 20 }}
            className="fixed inset-0 z-40 w-full h-full bg-luxury-dark/95 backdrop-blur-lg"
          >
            <div className="flex flex-col h-full p-8 pt-20">
              <nav className="space-y-6">
                {menuItems.map((item) => (
                  <motion.a
                    key={item.title}
                    href={item.href}
                    whileHover={{ x: 10 }}
                    className="block text-2xl font-serif text-luxury-light hover:text-luxury-gold transition-colors"
                  >
                    {item.title}
                  </motion.a>
                ))}
              </nav>

              <div className="mt-auto">
                <div className="flex gap-6 justify-center">
                  {socialLinks.map((social, index) => {
                    const Icon = social.icon;
                    return (
                      <motion.a
                        key={index}
                        href={social.href}
                        whileHover={{ y: -3 }}
                        className="text-luxury-gold hover:text-luxury-silver transition-colors"
                      >
                        <Icon className="w-6 h-6" />
                      </motion.a>
                    );
                  })}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};