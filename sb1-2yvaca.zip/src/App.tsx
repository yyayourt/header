import { Header } from './components/Header/Header';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-luxury-dark to-black text-luxury-light">
      <Header />
      <main className="pt-16">
        <div className="container mx-auto px-4">
          <section className="min-h-screen flex items-center justify-center">
            <h1 className="text-4xl md:text-6xl font-serif text-center">
              <span className="block text-luxury-gold">L'Excellence</span>
              <span className="block mt-2">dans chaque coupe</span>
            </h1>
          </section>
        </div>
      </main>
    </div>
  );
}

export default App;